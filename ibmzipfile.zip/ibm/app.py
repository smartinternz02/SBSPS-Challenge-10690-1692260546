from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
from sklearn.preprocessing import LabelEncoder

# Load the trained model
model = joblib.load('placement_model.pkl')

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    
    age = data['age']
    internships = data['internships']
    cgpa = data['cgpa']
    hostel = data['hostel']
    backlogs = data['backlogs']
    
    # Creating Label Encoders
    le_gender = LabelEncoder()
    le_stream = LabelEncoder()

    # Check if 'gender' exists in the input data and contains values
    if 'gender' in data and data['gender']:
        user_gender = data['gender']
        gender_encoded = le_gender.fit_transform([user_gender])
    else:
        # Handle the case where 'gender' is missing or empty
        gender_encoded = -1 
    
    # Check if 'stream' exists in the input data and contains values
    if 'stream' in data and data['stream']:
        user_stream = data['stream']
        stream_encoded = le_stream.fit_transform([user_stream])
    else:
        # Handle the case where 'stream' is missing or empty
        stream_encoded = -1  

    # Create a DataFrame from the user inputs
    user_data = pd.DataFrame([[age, gender_encoded[0], stream_encoded[0], internships, cgpa, hostel, backlogs]], columns=['Age', 'Gender', 'Stream', 'Internships', 'CGPA', 'Hostel', 'HistoryOfBacklogs'])

    # Use the trained model to make a prediction
    prediction = model.predict(user_data)
    
    result = {'acceptanceRate': prediction[0]*100}
    return jsonify({'acceptanceRate': int(result['acceptanceRate'])})

if __name__ == '__main__':
    app.run() 
